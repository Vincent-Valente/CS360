package com.example.cs360;

import android.Manifest;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;

public class PermissionRequestActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 101;
    private Button requestPermissionButton;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission_request);

        // Initialize shared preferences
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);

        // Check if the user is new or has accepted SMS notifications
        boolean isNewUser = sharedPreferences.getBoolean("IsNewUser", true);

        // Find the request permission button by its ID
        requestPermissionButton = findViewById(R.id.request_permission_button);

        // Set a click listener for the request permission button
        requestPermissionButton.setOnClickListener(v -> {
            if (isNewUser) {
                // Prompt new users to accept/deny SMS notifications
                showPermissionDialog();
            } else {
                // Existing user, request SMS permission directly
                requestSmsPermission();
            }
        });
    }

    // Method to request SMS permission
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Request the SMS permission if it has not been granted
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            // Display a toast message if SMS permission is already granted
            Toast.makeText(this, "SMS Permission already granted", Toast.LENGTH_SHORT).show();
            // Now you can send SMS messages here
            sendSMSMessage("phone_number_here", "Your event is coming up soon!");
        }
    }

    // Method to show a dialog for accepting/denying SMS notifications
    private void showPermissionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("SMS Notifications");
        builder.setMessage("Do you want to receive SMS notifications from this app?");
        builder.setPositiveButton("Accept", (dialog, which) -> {
            // User accepts SMS notifications
            sharedPreferences.edit().putBoolean("IsNewUser", false).apply();
            requestSmsPermission();
        });
        builder.setNegativeButton("Deny", (dialog, which) -> {
            // User denies SMS notifications
            sharedPreferences.edit().putBoolean("IsNewUser", false).apply();
            Toast.makeText(this, "SMS notifications denied. SMS notifications won't be sent.", Toast.LENGTH_SHORT).show();
        });
        builder.show();
    }

    // Handle the result of the SMS permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, you can send SMS messages
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
                sendSMSMessage("phone_number_here", "Your event is coming up soon!");
            } else {
                // Permission denied, inform the user
                Toast.makeText(this, "SMS Permission Denied. SMS notifications won't be sent.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Method to send an SMS message
    private void sendSMSMessage(String phoneNumber, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }
}
