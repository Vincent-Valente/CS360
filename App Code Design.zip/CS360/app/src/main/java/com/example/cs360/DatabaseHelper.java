package com.example.cs360;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Define table and column names as constants
    public static final String TABLE_EVENTS = "Events";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_EVENT_NAME = "event_name";
    public static final String COLUMN_EVENT_DATE = "event_date";
    public static final String TABLE_USERS = "Users";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    // New constant for the user column in the Events table
    public static final String COLUMN_USER = "user";

    // Constructor to initialize the database
    public DatabaseHelper(Context context) {
        super(context, "EventDB", null, 4);
    }

    // Create the database table when the database is created
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Events table
        String createTableStatement = "CREATE TABLE " + TABLE_EVENTS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_EVENT_NAME + " TEXT, " +
                COLUMN_EVENT_DATE + " TEXT," +
                COLUMN_USER + " TEXT)"; // Add COLUMN_USER to store the username
        db.execSQL(createTableStatement);

        // Create Users table
        String createUserTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_USERNAME + " TEXT PRIMARY KEY, " +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createUserTable);
    }

    // Method to check user credentials
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_USERNAME},
                COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password}, null, null, null);

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    // Handle database schema upgrades by dropping and recreating the table
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    // Method to register a new user
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_USERNAME, username);
        cv.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, cv);
        db.close();
        return result != -1;
    }

    // Method to add a new event to the database
    public boolean addEvent(Event event, String username) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_EVENT_NAME, event.getEventName());
        cv.put(COLUMN_EVENT_DATE, event.getEventDate());
        cv.put(COLUMN_USER, username); // Store the username with the event

        long insert = db.insert(TABLE_EVENTS, null, cv);
        db.close();
        return insert != -1;
    }

    // Method to update an existing event in the database
    public boolean updateEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_EVENT_NAME, event.getEventName());
        cv.put(COLUMN_EVENT_DATE, event.getEventDate());

        int update = db.update(TABLE_EVENTS, cv, COLUMN_ID + " = ?", new String[]{String.valueOf(event.getId())});
        db.close();
        return update > 0;
    }

    // Modify the getAllEvents method to get events for a specific user
    public Cursor getEventsByUser(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        if (username == null || username.isEmpty()) {
            // Return an empty Cursor for guest users
            return new MatrixCursor(new String[]{COLUMN_ID, COLUMN_EVENT_NAME, COLUMN_EVENT_DATE, COLUMN_USER});
        }

        String selection = COLUMN_USER + " = ?";
        String[] selectionArgs = { username };
        return db.query(TABLE_EVENTS, null, selection, selectionArgs, null, null, COLUMN_EVENT_DATE);
    }

    // Method to delete an event from the database based on its ID
    public boolean deleteEvent(int eventId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int delete = db.delete(TABLE_EVENTS, COLUMN_ID + " = ?", new String[]{String.valueOf(eventId)});
        db.close();
        return delete > 0;
    }

    // Method to retrieve all events from the database and return a cursor
    public Cursor getAllEvents() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_EVENTS, null, null, null, null, null, COLUMN_EVENT_DATE);
        // Do not close the database here as the cursor is still in use
        return cursor;
    }
}



