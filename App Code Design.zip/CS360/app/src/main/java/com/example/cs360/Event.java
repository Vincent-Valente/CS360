package com.example.cs360;

public class Event {
    private int id;
    private String eventName;
    private String eventDate;

    // Constructor to initialize an Event object with id, name, and date
    public Event(int id, String eventName, String eventDate) {
        this.id = id;
        this.eventName = eventName;
        this.eventDate = eventDate;
    }

    // Getter method for retrieving the event's ID
    public int getId() {
        return id;
    }

    // Getter method for retrieving the event's name
    public String getEventName() {
        return eventName;
    }

    // Getter method for retrieving the event's date
    public String getEventDate() {
        return eventDate;
    }

    // Setter method to update the event's name
    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    // Setter method to update the event's date
    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }
}
