package com.example.cs360;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.Manifest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class DataDisplayActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private Button addDataButton;
    private DataAdapter dataAdapter;
    private DatabaseHelper databaseHelper;
    private Button settingsButton;
    private Button logoutButton;
    private Button loginButton;
    private SharedPreferences sharedPreferences;

    private static final int SMS_PERMISSION_CODE = 101; // Define this constant at the top of your activity class

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String currentUser = sharedPreferences.getString("LoggedInUser", null);

        recyclerView = findViewById(R.id.data_recycler_view);
        addDataButton = findViewById(R.id.add_data_button);
        databaseHelper = new DatabaseHelper(this);
        dataAdapter = new DataAdapter(this, databaseHelper, currentUser);

        settingsButton = findViewById(R.id.button_settings);
        logoutButton = findViewById(R.id.button_logout);
        loginButton = findViewById(R.id.button_login);
        addDataButton.setOnClickListener(v -> showAddEventDialog());
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(dataAdapter);

        // Find and set click listeners for settings and logout buttons
        settingsButton.setOnClickListener(v -> openSettings());
        logoutButton.setOnClickListener(v -> logout());
        loginButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
        });

        // Check if user is logged in and adjust button visibility
        updateButtonVisibility();
    }

    private void updateButtonVisibility() {
        boolean isLoggedIn = checkUserLoginStatus();
        logoutButton.setVisibility(isLoggedIn ? View.VISIBLE : View.GONE);
        loginButton.setVisibility(isLoggedIn ? View.GONE : View.VISIBLE);
    }

    private boolean checkUserLoginStatus() {
        // Check if 'LoggedInUser' exists in SharedPreferences
        return sharedPreferences.contains("LoggedInUser");
    }

    // Method to navigate to the SettingsActivity
    private void openSettings() {
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }

    // Method to log out the user and navigate back to the LoginActivity
    private void logout() {
        // Clear the logged-in user information
        sharedPreferences.edit().remove("LoggedInUser").apply();
        updateButtonVisibility();
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish(); // Close the DataDisplayActivity
    }

    // Method to show a dialog for adding a new event
    private void showAddEventDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View subView = inflater.inflate(R.layout.dialog_add_event, null);
        final EditText nameEditText = subView.findViewById(R.id.dialogNameEditText);
        final EditText dateEditText = subView.findViewById(R.id.dialogDateEditText);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Event");
        builder.setView(subView);
        builder.create();

        builder.setPositiveButton("ADD EVENT", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                final String name = nameEditText.getText().toString();
                final String date = dateEditText.getText().toString();
                if (!name.isEmpty() && !date.isEmpty()) {
                    // Retrieve the current user's username from SharedPreferences
                    String currentUser = sharedPreferences.getString("LoggedInUser", null);

                    if (currentUser != null) {
                        Event newEvent = new Event(-1, name, date);
                        if (databaseHelper.addEvent(newEvent, currentUser)) {
                            dataAdapter.notifyDataSetChanged();
                        }
                    } else {
                        Toast.makeText(DataDisplayActivity.this, "You need to be logged in to add events.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(DataDisplayActivity.this, "Fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(DataDisplayActivity.this, "Task cancelled", Toast.LENGTH_SHORT).show();
            }
        });

        builder.show();
    }

    // Method to request SMS permission
    public void requestSmsPermission(View view) {
        // Check if the SMS permission has been granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // If not, request the permission
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        } else {
            // Permission has already been granted
            Toast.makeText(this, "SMS permission already granted.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    // Handle the result of the SMS permission request
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission was granted
                Toast.makeText(this, "SMS permission granted.",
                        Toast.LENGTH_SHORT).show();
                // Here you can enable features that require SMS
            } else {
                // Permission was denied
                Toast.makeText(this, "SMS permission denied.",
                        Toast.LENGTH_SHORT).show();
                // Continue without features that require SMS
            }
        }
    }
}



