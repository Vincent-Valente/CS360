package com.example.cs360;

import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.DataViewHolder> {

    // Context to be used for various Android framework operations.
    private Context context;

    // Helper class for database operations.
    private DatabaseHelper databaseHelper;

    // Declare currentUser as a member variable
    private String currentUser;

    // Constructor to initialize the adapter with context and database helper.
    public DataAdapter(Context context, DatabaseHelper databaseHelper, String currentUser) {
        this.context = context;
        this.databaseHelper = databaseHelper;
        this.currentUser = currentUser;
    }

    // This method is called when a new ViewHolder object needs to be created.
    @NonNull
    @Override
    public DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflating the layout for each item view from XML.
        View view = LayoutInflater.from(context).inflate(R.layout.item_data, parent, false);
        return new DataViewHolder(view); // Creating a new DataViewHolder.
    }

    // This method is called to bind data to a ViewHolder.
    @Override
    public void onBindViewHolder(@NonNull DataViewHolder holder, int position) {
        try (Cursor cursor = databaseHelper.getEventsByUser(currentUser)) {
            if (cursor.moveToPosition(position)) {
                // Extracting data from the cursor.
                int idIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID);
                int nameIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_NAME);
                int dateIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_EVENT_DATE);

                int id = cursor.getInt(idIndex);
                String name = cursor.getString(nameIndex);
                String date = cursor.getString(dateIndex);
                Event event = new Event(id, name, date);

                // Updating the UI elements of the ViewHolder.
                holder.eventNameTextView.setText(event.getEventName());
                holder.eventDateTextView.setText(event.getEventDate());

                // Setting click listeners for edit and delete buttons.
                holder.editButton.setOnClickListener(v -> editEvent(event, position));
                holder.deleteButton.setOnClickListener(v -> deleteEvent(event, position));
            }
        }
    }

    // Method to delete an event from the database and update the RecyclerView.
    private void deleteEvent(Event event, int position) {
        if (databaseHelper.deleteEvent(event.getId())) {
            // Notify RecyclerView about the item removal and position changes.
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, getItemCount());
        }
    }

    // Method to edit an event and update the RecyclerView.
    private void editEvent(Event event, int position) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View subView = inflater.inflate(R.layout.dialog_add_event, null);
        final EditText nameEditText = subView.findViewById(R.id.dialogNameEditText);
        final EditText dateEditText = subView.findViewById(R.id.dialogDateEditText);

        // Pre-fill the dialog with the current event details
        nameEditText.setText(event.getEventName());
        dateEditText.setText(event.getEventDate());

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Edit Event");
        builder.setView(subView);
        builder.create();

        builder.setPositiveButton("SAVE CHANGES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newName = nameEditText.getText().toString();
                String newDate = dateEditText.getText().toString();
                if (!newName.isEmpty() && !newDate.isEmpty()) {
                    // Update the event with the new details
                    event.setEventName(newName);
                    event.setEventDate(newDate);
                    if (databaseHelper.updateEvent(event)) {
                        // If the database is updated successfully, notify the adapter
                        notifyItemChanged(position);
                    }
                } else {
                    Toast.makeText(context, "Please fill all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(context, "Edit cancelled", Toast.LENGTH_SHORT).show();
            }
        });

        builder.show();
    }

    // This method returns the total number of items in the RecyclerView.
    @Override
    public int getItemCount() {
        try (Cursor cursor = databaseHelper.getEventsByUser(currentUser)) {
            return cursor.getCount();
        }
    }

    // ViewHolder class for holding and caching item view components.
    public class DataViewHolder extends RecyclerView.ViewHolder {
        TextView eventNameTextView;
        TextView eventDateTextView;
        Button editButton;
        Button deleteButton;

        // Constructor to initialize view components.
        public DataViewHolder(View itemView) {
            super(itemView);
            eventNameTextView = itemView.findViewById(R.id.text_data_name);
            eventDateTextView = itemView.findViewById(R.id.text_data_value);
            editButton = itemView.findViewById(R.id.button_edit);
            deleteButton = itemView.findViewById(R.id.button_delete);
        }
    }
}



