package com.example.cs360;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private SharedPreferences sharedPreferences;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Find the EditText views by their IDs in the layout
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);

        // Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Initialize SharedPreferences for user preferences
        sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
    }

    // Method called when the "Login" button is clicked
    public void onLoginClicked(View view) {
        String user = usernameEditText.getText().toString();
        String pass = passwordEditText.getText().toString();

        if (databaseHelper.checkUser(user, pass)) {
            sharedPreferences.edit().putString("LoggedInUser", user).apply();

            // Navigate to DataDisplayActivity
            Intent intent = new Intent(this, DataDisplayActivity.class);
            intent.putExtra("username", user);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
        }
    }

    // Method called when the "Continue as Guest" button is clicked
    public void onContinueAsGuestClicked(View view) {
        Intent intent = new Intent(this, DataDisplayActivity.class);
        startActivity(intent);
        finish(); // Close the LoginActivity
    }

    // Method called when the "Register" button is clicked
    public void onRegisterClicked(View view) {
        String user = usernameEditText.getText().toString();
        String pass = passwordEditText.getText().toString();

        if (!user.isEmpty() && !pass.isEmpty()) {
            if (databaseHelper.registerUser(user, pass)) {
                Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "User already exists", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
        }
    }
}