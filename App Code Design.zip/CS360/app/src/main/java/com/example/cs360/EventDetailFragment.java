package com.example.cs360;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class EventDetailFragment extends Fragment {

    private TextView eventNameTextView;
    private TextView eventDateTextView;
    private DatabaseHelper databaseHelper;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_event_detail, container, false);

        // Initialize the DatabaseHelper
        databaseHelper = new DatabaseHelper(getActivity());

        // Find TextViews by their IDs in the layout
        eventNameTextView = view.findViewById(R.id.eventName);
        eventDateTextView = view.findViewById(R.id.eventDate);

        // Retrieve the eventId argument
        if (getArguments() != null) {
            int eventId = getArguments().getInt("eventId");
            displayEventDetails(eventId);
        }

        return view;
    }

    // Method to display event details based on the provided eventId
    private void displayEventDetails(int eventId) {
        // Query the database to retrieve event details based on the eventId
        Cursor cursor = databaseHelper.getReadableDatabase().query(
                "Events", null, "id = ?", new String[]{String.valueOf(eventId)},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            int eventNameIndex = cursor.getColumnIndex("event_name");
            int eventDateIndex = cursor.getColumnIndex("event_date");

            if (eventNameIndex != -1) {
                String eventName = cursor.getString(eventNameIndex);
                eventNameTextView.setText(eventName);
            }

            if (eventDateIndex != -1) {
                String eventDate = cursor.getString(eventDateIndex);
                eventDateTextView.setText(eventDate);
            }

            cursor.close(); // Close the cursor when done with it
        }
    }
}

